<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Brand Management</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
      <div class="col-md-8">
            <div class="box box-danger">
            <div class="box-header">
              <h3 class="box-title">All Brands</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive">
              <table class="table table-hover" id="newbrand">
                <thead>
                   <tr>
                  <th>Brand Name</th>
                  <th>Action</th>
                </tr>
                </thead>
               <tbody>
                  <?php $__currentLoopData = @$brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td><?php echo e($row->name); ?></td>
                <td><a href="<?php echo e(route('edit_brand',$row->id)); ?>"><span class="label label-primary">Edit</span></a>
                <a href="<?php echo e(route('del.brand',$row->id)); ?>" onclick="return confirm('Are you sure you want to delete this item?');"><span class="label label-danger">Delete</span></a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </tbody>
               
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
      </div>
      <div class="col-md-4">
        <div class="box box-info">
      
            <div class="box-header with-border">

              <h3 class="box-title">Brand</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form class="form-horizontal" action="<?php echo e(route('brand')); ?>" method="POST">
              <?php echo csrf_field(); ?>
              
           
              <div class="box-body">
                <div class="col-md-12">
                  <label for="name" class=" control-label">Brand Name</label>

                  <div class="">
                    <input type="text" name="name" class="form-control" id="name" placeholder="Brand Name">
                  </div>
                </div>
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                
                <button type="submit" class="btn btn-info pull-right">Submit</button>
              </div>
              <!-- /.box-footer -->
            </form>
          </div>
      </div>
    
      </div>
     
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript">
      $(function () {
         $('.select2').select2();
    $('#newbrand').DataTable();
   

  });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
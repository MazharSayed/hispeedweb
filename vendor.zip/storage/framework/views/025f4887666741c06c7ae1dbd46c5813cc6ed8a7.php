<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>

    <h1>Customer Details</h1>
 <div class="panel panel-default">
        <div class="panel-heading">
            Customer Details
        </div>

        <div class="panel-body table-responsive">
            <div class="row">
                <div class="col-md-6">
                    <table class="table table-bordered table-striped">
                       
                       
                         
                    <tr>
                            <th>Date Of Birth</th>
                            <td><?php echo e($cust->dob); ?></td>
                        </tr>
                        <tr>
                            <th>Gender</th>
                            <td><?php echo e($cust->gender); ?></td>
                        </tr>
                        <tr>
                            <th>Reference Code</th>
                            <td><?php echo e($cust->reference_code); ?></td>
                        </tr>
                        <tr>
                            <th>Current Address</th>
                            <td><?php echo e($cust->current_address); ?></td>
                        </tr>
                        <tr>
                            <th>Permanent Address</th>
                            <td><?php echo e($cust->permanent_address); ?></td>
                        </tr>
                        <tr>
                            <th>Pin Code</th>
                            <td><?php echo e($cust->pin_code); ?></td>
                        </tr>
            <tr>
                            <th>Residence Type</th>
                            <td><?php echo e($cust->vresidence_type); ?></td>
                        </tr>
                        <tr>
                            <th>aadhar_number</th>
                            <td><?php echo e($cust->aadhar_number); ?></td>
                        </tr>
                        <tr>
                            <th>aadhar_photo</th>
                            <td><?php echo e($cust->aadhar_photo); ?></td>
                        </tr>
                        <tr>
                            <th>pan_number</th>
                            <td><?php echo e($cust->pan_number); ?></td>
                        </tr>
                        <tr>
                            <th>pan_photo</th>
                            <td><?php echo e($cust->pan_photo); ?></td>
                        </tr>
                        <tr>
                            <th>bank_passbook_photo</th>
                            <td><?php echo e($cust->bank_passbook_photo); ?></td>
                        </tr>
                        <tr>
                            <th>employment_type</th>
                            <td><?php echo e($cust->employment_type); ?></td>
                        </tr>
                        <tr>
                            <th>District</th>
                            <td><?php echo e($cust->permenent_district); ?></td>
                        </tr>
                        <tr>
                            <th>family_member_name</th>
                            <td><?php echo e($cust->family_member_name); ?></td>
                        </tr>
                        <tr>
                            <th>family_member_number</th>
                            <td><?php echo e($cust->family_member_number); ?></td>
                        </tr>
                        <tr>
                            <th>family_member_relation</th>
                            <td><?php echo e($cust->family_member_relation); ?></td>
                        </tr>
                        <tr>
                            <th>Guarantor Name</th>
                            <td><?php echo e($cust->guarantor_name); ?></td>
                        </tr>
                        <tr>
                            <th>guarantor_mobile_number</th>
                            <td><?php echo e($cust->guarantor_mobile_number); ?></td>
                        </tr>
                        <tr>
                            <th>Status</th>
                            <td><?php echo e($cust->status); ?></td>
                        </tr>
                        <tr>
                            <th>Image</th>
                            <td><?php echo e($cust->image); ?></td>
                        </tr>
                        
                    </table>

                </div>
                <div class="col-md-6">
                    <div class="panel-heading">
                        Documents
                     </div>
                    <table class="table table-bordered table-striped">
                        <tr>
                            <th>Adhar Card</th>
                            <td field-key='description'><a href="" target="_blank">Click Here to view</a></td>
                        </tr>
                        <tr>
                            <th>PAN</th>
                            <td field-key='description'><a href="" target="_blank">Click Here to view</a></td>
                        </tr>
                        <tr>
                            <th>Bank Reciept</th>
                            <td field-key='description'><a href="" target="_blank"><img src="" width="100"></a></td>
                        </tr>

                        
                        <tr>
                            <th>Image </th>
                            <td field-key='image'>
                                    <a href="" target="_blank"><img src="" style="width: 100px"/></a>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            <p>&nbsp;</p>
            <a href="<?php echo e(route('cust.req')); ?>" class="btn btn-default">Back to List</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
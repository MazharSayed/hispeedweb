<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Register Customer Management</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



<div class="col-md-12">
            <div class="box box-danger">
            <div class="box-header">
              <h3 class="box-title">All Register Customers</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive">
              <table class="table table-hover" id="customer">
                <thead>
                   <tr>
                  <th>First Name</th>
                  <th>Last Name</th>
                  <th>Email</th>
                  <th>Mobile Number</th>
                  <th>Action</th>
                </tr>
                </thead>
               <tbody>
                  <?php $__currentLoopData = @$cust_req; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td><?php echo e(@App\Customer::where('id',$row->customer_id)->value('first_name')); ?></td>
                <td><?php echo e(@App\Customer::where('id',$row->customer_id)->value('last_name')); ?></td>
                <td><?php echo e(@App\Customer::where('id',$row->customer_id)->value('email')); ?></td>
              <td><?php echo e(@App\Customer::where('id',$row->customer_id)->value('mobile_number')); ?></td>
                <!-- <td><a href="<?php echo e(route('edit_cate',$row->id)); ?>"><span class="label label-primary">Edit</span></a> -->
                <td><a href="<?php echo e(route('del.register',$row->id)); ?>" onclick="return confirm('Are you sure you want to delete this item?');"><span class="label label-danger">Delete</span></a>
                      <a href="<?php echo e(route('req.detail',$row->id)); ?>"><span class="label label-info"><i class="fa fa-eye"></i>&ensp;See Details</span></a></td> 
              </td> 
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
      </div>









<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript">
      $(function () {
         $('.select2').select2();
    $('#category').DataTable();
   

  });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
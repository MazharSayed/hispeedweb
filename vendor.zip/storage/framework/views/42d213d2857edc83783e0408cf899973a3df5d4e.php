<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Edit Product</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   	<div class="col-md-8">
            <div class="box box-info">
      
            <div class="box-header with-border">

              <h3 class="box-title">Edit Product</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
         <form class="form-horizontal" action="<?php echo e(route('edit_product',$user->id)); ?>" method="POST"  enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
           
             
                <div class="box-body">
                <div class="col-md-10">
                  <label for="name" class=" control-label">Product Name</label>
                  <div class="">
                    <input type="text" name="name" class="form-control" id="name" value="<?php echo e($user->name); ?>">
                  </div>
                </div>
                <div class="col-md-10">
                  <label for="prop_name" class=" control-label">Category</label>
                <select class="form-control select2"  name="category_id" data-placeholder="Select Category" required>
                  <?php $__currentLoopData = @App\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($row->id); ?>" <?php if($user->category_id==$row->id): ?> selected <?php endif; ?>><?php echo e($row->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                </div>  
                <div class="col-md-10">
                  <label for="prop_name" class=" control-label">Brand</label>
                <select class="form-control select2"  name="brand_id" data-placeholder="Select Brand" required>
                  <?php $__currentLoopData = @App\Brand::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($row->id); ?>" <?php if($user->brand_id==$row->id): ?> selected <?php endif; ?>><?php echo e($row->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                </div>
                <div class="col-md-10 "> 
                  <label for="image" class=" control-label">Image</label>
                    <input type="file" name="image" class="form-control" id="image">
                  </div>
                
                <div class="col-md-10">
                  <label for="images" class=" control-label">Multiple Image</label>
                   <input type="file" name="images[]" class="form-control" id="images"  multiple>
                  </div>
                <!--  <div class="form-group">
                  <label for="image" class="col-sm-2 control-label">Image</label>
                  <div class="col-sm-10 mt-3">
                    <input type="file" name="image" class="form-control" id="image">
                  </div>
                </div>
                <div class="form-group">
                  <label for="images" class="col-sm-2 control-label">Multiple Image</label>

                  <div class="col-sm-10">
                   <input type="file" name="images[]" class="form-control" id="images"  multiple>
                  </div>
                </div> -->
                 <div class="col-md-10">
                  <label for="interest" class=" control-label">Interest</label>
                  <div class="">
                    <input type="number" name="interest" class="form-control" id="interest" value="<?php echo e($user->interest); ?>">
                  </div>
                </div>
                <div class="col-md-10">
                  <label for="price" class=" control-label">Price</label>
                  <div class="">
                    <input type="number" name="price" class="form-control" id="price" value="<?php echo e($user->price); ?>">
                  </div>
                </div>   
                <div class=" col-md-10">
                  <label for="description" class=" control-label">Description</label>
                     <textarea class="textarea" placeholder="Type Here"
                            style="width: 100%; height: 125px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;" name="description"
                           id="description"><?php echo e($user->description); ?></textarea>
                </div>    
              </div>
              
             <div class="box-footer">
                <button type="submit" class="btn btn-info pull-right">Edit</button>
              </div>
              <!-- /.box-footer -->
            </form>
          </div>
        </div>


 <?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script type="text/javascript">
      $(function () {
         $('.select2').select2();
    $('#product').DataTable();
   
//Timepicker
   
  });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
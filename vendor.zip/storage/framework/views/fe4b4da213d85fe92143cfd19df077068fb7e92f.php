

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Customer Management</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



<div class="col-md-12">
            <div class="box box-danger">
            <div class="box-header">
              <h3 class="box-title">All Customers</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive">
              <table class="table table-hover" id="customer">
                <thead>
                   <tr>
                  <th>First Name</th>
                  <th>Last Name</th>
                  <th>Email</th>
                  <th>Mobile Number</th>
                  <th>Referal Code</th>
                  <th>Action</th>
                </tr>
                </thead>
               <tbody>
                  <?php $__currentLoopData = @$customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td><?php echo e($row->first_name); ?></td>
                <td><?php echo e($row->last_name); ?></td>
                <td><?php echo e($row->email); ?></td>
                <td><?php echo e($row->mobile_number); ?></td>
                <td><?php echo e($row->referal_id); ?></td>
                <!-- <td><a href="<?php echo e(route('edit_cate',$row->id)); ?>"><span class="label label-primary">Edit</span></a> -->
               <td><a href="<?php echo e(route('del.cust',$row->id)); ?>" onclick="return confirm('Are you sure you want to delete this item?');"><span class="label label-danger">Delete</span></a></td> 
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
      </div>









<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript">
      $(function () {
         $('.select2').select2();
    $('#category').DataTable();
   

  });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>